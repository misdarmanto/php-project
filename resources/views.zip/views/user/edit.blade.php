@extends('layouts.master')

@section ('content')
<div class="main">
	<div class="main-content">
		<div class="container-fluid">
			<h1 class="page-title">Formulir Data Diri Pemain</h1>
			<div class="row">
				
				
				<div class="col-md-6">
					
						<div class="panel">
						<div class="panel-heading">
									<h3 class="panel-title">Data Diri</h3>
								</div>

									<form action="/anggota/{{$anggota->id}}/update" method="POST" enctype="multipart/form-data">
							{{csrf_field()}}



						<div class="panel-body">
					  <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Nama Lengkap</label>
					    <input type="text" name="nama_lengkap" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->nama_lengkap}}" >
					    </div>
					    <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Nama Panggilan</label>
					    <input type="text" name="nama_pangilan" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->nama_panggilan}}" >
					    </div>
					    <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Tempat/Tanggal Lahir</label>
					    <input type="text" name="lahir" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->lahir}}" >
					    </div>
					     <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Alamat</label>
					    <input type="text" name="alamat" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->alamat}}" >
					    </div>
						
					 
						<div class="form-group">
							  <label for="exampleFormControlTextarea1" class="form-label">Avatar</label>
							  <input type="file" name="avatar" class="form-control">
							</div>
						<div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">ssb pemain saat ini</label>
					    <input type="text" name="ssb_pemain" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->ssb_pemain}}" >
					    </div>
					    <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">nama ayah</label>
					    <input type="text" name="ayah" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->ayah}}" >
					    </div>
					    <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">nama ibu</label>
					    <input type="text" name="ibu" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->ibu}}" >
					    </div>
					    <div class="form-group">
					    	<label for="exampleFormControlSelect1">Pilih Administrasi pemain</label>
						<select name="admin_pemain" class="form-control" aria-label="Default select example" >
						
						  <option value="AKTE" @if($anggota->admin_pemain == 'AKTE') selected @endif>AKTE</option>
						  <option value="NISN" @if($anggota->admin_pemain == 'NISN') selected @endif>NISN</option>
						  <option value="KK" @if($anggota->admin_pemain == 'KK') selected @endif>KK</option>
						  <option value="RAPORT" @if($anggota->admin_pemain == 'RAPORT') selected @endif>RAPORT</option>
						  <option value="PASSPOR" @if($anggota->admin_pemain == 'PASSPOR') selected @endif>PASSPOR</option>
						  </select>
						  <div class="form-group">
					    	<label for="exampleFormControlSelect1">Pilih golongan darah</label>
						<select name="darah" class="form-control" aria-label="Default select example" >
						
						  <option value="A" @if($anggota->admin_pemain == 'A') selected @endif>A</option>
						  <option value="B"@if($anggota->admin_pemain == 'B') selected @endif>B</option>
						  <option value="AB"@if($anggota->admin_pemain == 'AB') selected @endif>AB</option>
						  <option value="O"@if($anggota->admin_pemain == 'O') selected @endif>O</option>
						  
						  </select>

						   <div class="form-group">
					    	<label for="exampleFormControlSelect1">Pilih Jenis Kelamin</label>
						<select name="jenis_kelamin" class="form-control" aria-label="Default select example" >
						
						  <option value="L" @if($anggota->jenis_kelamin == 'L') selected @endif>Laki-laki</option>
						  <option value="P" @if($anggota->jenis_kelamin == 'P') selected @endif>Perempuan</option>
						  </select>
						</div>
						<div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">berat badan</label>
					    <input type="number" name="berat" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->berat}}" >
					    </div>

					     <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">tinggi badan</label>
					    <input type="number" name="tinggi" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->tinggi}}" >
					    </div>



					</div>
				</div>
			</div>
				
			</div>
		</div>
				<div class="col-md-6">
							<!-- LABELS -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Riwayat Pendidikan Formal</h3>
								</div>

								<div class="panel-body">

						 <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">SD</label>
					    <input type="text" name="sd" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->sd}}">
					    </div>

					     <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">SMP</label>
					    <input type="text" name="smp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="{{$anggota->smp}}" >
					    </div>
					    <button type="submit" class="btn btn-warning ">Submit</button>

					 </form>
							
								</div>
				</div>
			</div>


						

							<br>
							
								</div>
				</div>
			</div>




		</div>
	</div>
</div>


@stop
@section('content1')
	<h1> Edit Data Anggota </h1>
	@if(session('sukses'))
	<div class="alert alert-success" role="alert">
  {{session('sukses')}}
</div>
@endif
	<div class="row">
		<div class="col-lg-12">
		
			<!-- Modal -->
			
			      
						<form action="" method="POST">
							{{csrf_field()}}
					  <div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Nama Depan</label>
					    <input type="text" name="nama_depan" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Depan" >
					    </div>
					     <div class="mb-3">
					    <label for="exampleInputEmail1" class="form-label">Nama Belakang</label>
					    <input type="text" name="nama_belakang" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Belakang" >
					    </div>
					    <div class="form-group">
					    	<label for="exampleInputEmail1" class="form-label">Pilih Jenis Kelamin</label>
						<select name="jenis_kelamin" class="form-select" aria-label="Default select example" >
						
						  <option value="L" </option>
						  <option value="P" </option>
						  </select>
						</div>
						<div class="form-group">
					    <label for="exampleInputEmail1" class="form-label">Agama</label>
					    <input name="agama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Agama" >
					    </div>
					    <div class="form-group">
							  <label for="exampleFormControlTextarea1" class="form-label">Alamat</label>
							  <textarea name="alamat" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
							</div>
							<br>
							<button type="submit" class="btn btn-warning ">Update</button>

					 </form></div>

			      	
			         
					
				</div>
			    </div>
			</div>
		</div>
</div>



</div>
@endsection