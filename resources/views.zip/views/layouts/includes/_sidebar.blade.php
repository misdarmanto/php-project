<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						@if(auth()->user()->role == 'anggota')
						<li><a href="/dashboard" class=" {{ Request::is('dashboard') ? 'active' :''}}"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="/pengajuan" class="{{ Request::is('pengajuan') ? 'active' :''}}"><i class="lnr lnr-rocket"></i> <span>Pengajuan</span></a></li>
						<li><a href="/pengajuan/disetujui" class="{{ Request::is('publikasi/disetujui') ? 'active' :''}}"><i class="fa fa-thumbs-up"></i> <span>Disetujui</span></a></li>
						<li><a href="/pengajuan/ditolak" class="{{ Request::is('publikasi/ditolak') ? 'active' :''}}"><i class="lnr lnr-pencil"></i> <span>Ditolak</span></a></li>
						
						
						@endif
						@if(auth()->user()->role == 'admin')
						<li><a href="/dashboard" class=" {{ Request::is('dashboard') ? 'active' :''}}"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="/verifikasi" class="{{ Request::is('verifikasi') ? 'active' :''}}"><i class="lnr lnr-rocket"></i> <span>Verifikasi</span></a></li>
						<li><a href="/user" class=""><i class="lnr lnr-user"></i> <span>User</span></a></li>
						<li><a href="/author" class=""><i class="lnr lnr-user"></i> <span>Author</span></a></li>
						<li><a href="/prodi" class=""><i class="lnr lnr-pencil"></i> <span>Prodi</span></a></li>
						<li><a href="/type" class=""><i class="lnr lnr-pencil"></i> <span>Tipe Dokumen</span></a></li>
						<li><a href="/repo" class=""><i class="lnr lnr-pencil"></i> <span>Repository</span></a></li>
						
						
						@endif
					</ul>
				</nav>
			</div>
		</div>